import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

df = sns.load_dataset("tips")

print(df.info())
print(df.describe(include="all"))
print(df.isnull().sum())

group_avg = df.groupby(["day", "sex"])[["total_bill", "tip"]].agg("mean")
print(group_avg)

df["tip_rate"] = df["tip"] / df["total_bill"]

tip_rate_avg = df.groupby(["day", "time"])["tip_rate"].mean()
print(tip_rate_avg)

plt.figure(figsize=(7,5))
for sex in df["sex"].unique():
    s = df[df["sex"] == sex]
    plt.scatter(s["total_bill"], s["tip_rate"], label=sex)

plt.xlabel("Total Bill")
plt.ylabel("Tip Rate")
plt.title("Total Bill vs Tip Rate by Sex")
plt.legend()
plt.tight_layout()
plt.show()
